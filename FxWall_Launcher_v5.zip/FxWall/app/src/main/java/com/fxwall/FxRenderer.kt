package com.fxwall

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

/** Общий рендерер: используется и живыми обоями, и превью в приложении. */
class FxRenderer(private val ctx: Context) {
    private val MW = 14
    private val MH = 26
    private val MWF = 30
    private val MHF = 56
    private val prefs = Prefs.sp(ctx)

    var w = 0
        private set
    var h = 0
        private set
    var tiltX = 0f
    var tiltY = 0f
    var offsetX = 0.5f
    var tiltTargetX = 0f
    var tiltTargetY = 0f
    var offsetTarget = 0.5f
    var onFx: (() -> Unit)? = null
    var batteryPct = 100
    var charging = false

    private class P(var x: Float, var y: Float, var v: Float, var r: Float, var ph: Float)
    private class Shock(val x: Float, val y: Float, var t: Float, val amp: Float, val speed: Float)
    private class Spark(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val hue: Float = -1f)
    private class Ripple(val x: Float, val y: Float, var r: Float)
    private class TP(val x: Float, val y: Float, var age: Float)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bufPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mat = Matrix()
    private val srcR = Rect()
    private val dstR = RectF()
    private val fullR = RectF()
    private val bs = 0.5f
    private val verts = FloatArray((MWF + 1) * (MHF + 1) * 2)

    private var parts = ArrayList<P>()
    private var heads = FloatArray(0)
    private var lastKey = ""
    private var t = 0f
    private var curDt = 0.016f
    private var lastNs = 0L
    private var hueCur = -1f

    private var jellyT = -1f
    private var animKind = 0
    private var animT = 0f
    private val shocks = ArrayList<Shock>()
    private val sparks = ArrayList<Spark>()
    private val ripples = ArrayList<Ripple>()
    private val trail = ArrayList<TP>()
    private var chargeGlow = 0f
    private var eggT = -1f
    private var tapCount = 0
    private var wigMask: ByteArray? = null
    private var wigMW = 0
    private var wigMH = 0
    private var wigVer = -1L
    private var wigT = -1f
    private var wigDrive = 0f
    private var wigAmp = 0f
    private var prevTX = 0f
    private var prevTY = 0f
    private var fineMesh = false
    private var chargeHue = 140f

    private var buf: Bitmap? = null
    private var bufC: Canvas? = null
    private var bg: Bitmap? = null
    private var bgVer = -1L

    private var lastDown = 0L
    private var lastDownX = 0f
    private var lastDownY = 0f
    private var moveCnt = 0

    private val chars = "01アイウエオカキクケコサシスセソ<>/\\=+*#".toCharArray()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())

    // ---------- публичный API ----------

    fun trigger(kind: Int) {
        if (w == 0) return
        var k = kind
        if (k == 7) { val pool = intArrayOf(1, 2, 3, 4, 5, 6, 8, 9); k = pool[Random.nextInt(pool.size)] }
        when (k) {
            1 -> jellyT = 0f
            2 -> addShock(w / 2f, h * 0.55f, 90f * inten(), 1100f)
            3, 4, 5, 6, 9 -> { animKind = k; animT = 0f }
            8 -> {
                val q = inten()
                addShock(w / 2f, h * 0.5f, 55f * q, 700f)
                addShock(w / 2f, h * 0.5f, 40f * q, 1000f, -0.18f)
                addShock(w / 2f, h * 0.5f, 28f * q, 1400f, -0.36f)
            }
        }
        if (k != 0) {
            if (prefs.getBoolean("wigOn", false)) wigT = 0f
            onFx?.invoke()
        }
    }

    /** Запустить Wiggle вручную (кнопка «Тест»). */
    fun wiggle() { wigT = 0f }

    fun onPower(connected: Boolean) {
        if (w == 0 || !prefs.getBoolean("chargeFx", true)) return
        addShock(w / 2f, h.toFloat(), 70f * inten(), 1000f)
        chargeGlow = 1f
        chargeHue = if (connected) 140f else 15f
    }

    fun reset() {
        jellyT = -1f; animKind = 0; shocks.clear()
    }

    fun onTouch(e: MotionEvent) {
        val type = prefs.getInt("touch", 1)
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val now = System.currentTimeMillis()
                if (now - lastDown < 380 && hypot(x - lastDownX, y - lastDownY) < 170f) tapCount++ else tapCount = 1
                lastDown = now; lastDownX = x; lastDownY = y
                if (tapCount == 2 && prefs.getBoolean("dtap", true)) trigger(1)
                else if (tapCount == 3) { fireworks(x, y); tapCount = 0 }
                if (prefs.getBoolean("wigOn", false)) wigT = 0f
                when (type) {
                    1 -> ripples.add(Ripple(x, y, 10f))
                    2 -> burst(x, y, 16)
                    3 -> trail.add(TP(x, y, 0f))
                    4 -> addShock(x, y, 45f, 800f)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                moveCnt++
                when (type) {
                    1 -> if (moveCnt % 5 == 0 && ripples.size < 14) ripples.add(Ripple(x, y, 10f))
                    2 -> burst(x, y, 3)
                    3 -> if (trail.size < 60) trail.add(TP(x, y, 0f))
                }
            }
        }
    }

    fun release() {
        freeBuf()
        bg?.recycle(); bg = null; bgVer = -1L
    }

    fun render(c: Canvas, width: Int, height: Int) {
        if (width != w || height != h) { w = width; h = height; lastKey = ""; freeBuf() }
        if (w == 0 || h == 0) return
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
        lastNs = now
        curDt = dt
        t += dt
        loadBg()
        loadWig()
        update(dt)

        val wigOn = prefs.getBoolean("wigOn", false) && wigMask != null
        fineMesh = wigOn
        val tjOn = prefs.getInt("tiltJelly", 0) > 0 && wigDrive > 0.015f
        val need = jellyT >= 0f || shocks.isNotEmpty() || animKind != 0 ||
                (wigOn && wigAmp > 0.015f) || tjOn
        if (need && ensureBuf()) {
            val bc = bufC!!
            bc.save(); bc.scale(bs, bs)
            drawScene(bc)
            bc.restore()
            composite(c)
        } else {
            drawScene(c)
        }
    }

    // ---------- обновление состояния ----------

    private fun inten() = 0.3f + prefs.getInt("uInt", 50) / 60f

    private fun addShock(x: Float, y: Float, amp: Float, speed: Float, delay: Float = 0f) {
        if (shocks.size > 6) shocks.removeAt(0)
        shocks.add(Shock(x, y, delay, amp, speed))
    }

    /** Пасхалка: тройной тап по обоям. */
    private fun fireworks(x: Float, y: Float) {
        onFx?.invoke()
        jellyT = 0f
        addShock(x, y, 70f * inten(), 800f)
        addShock(x, y, 45f * inten(), 1200f)
        for (i in 0 until 140) {
            if (sparks.size > 400) break
            val a = Random.nextFloat() * 6.283f
            val sp = 120f + Random.nextFloat() * 620f
            sparks.add(Spark(x, y, cos(a) * sp, sin(a) * sp - 140f, 1.5f, (i * 360f / 140f + t * 40f) % 360f))
        }
        eggT = 0f
    }

    private fun burst(x: Float, y: Float, n: Int) {
        for (i in 0 until n) {
            if (sparks.size > 300) break
            val a = Random.nextFloat() * 6.283f
            val s = 150f + Random.nextFloat() * 350f
            sparks.add(Spark(x, y, cos(a) * s, sin(a) * s - 100f, 1f))
        }
    }

    private fun animDur(k: Int) = when (k) { 3 -> 1.0f; 4 -> 0.8f; 5 -> 0.7f; 9 -> 1.2f; else -> 1.8f }

    private fun targetHue(): Float {
        val base = prefs.getInt("hue", 210).toFloat()
        return when (prefs.getInt("colorMode", 0)) {
            1 -> {
                val cal = Calendar.getInstance()
                val frac = (cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)) / 1440f
                (frac * 360f + 220f) % 360f
            }
            2 -> if (charging) 180f else batteryPct * 1.2f
            3 -> (t * 12f) % 360f
            else -> base
        }
    }

    private fun update(dt: Float) {
        val kt = 1f - exp(-dt * 7f)
        tiltX += (tiltTargetX - tiltX) * kt
        tiltY += (tiltTargetY - tiltY) * kt
        offsetX += (offsetTarget - offsetX) * (1f - exp(-dt * 5f))
        if (eggT >= 0f) { eggT += dt; if (eggT > 2.4f) eggT = -1f }
        val vel = hypot(tiltX - prevTX, tiltY - prevTY) / max(dt, 0.001f)
        prevTX = tiltX; prevTY = tiltY
        wigDrive += (min(vel * 0.8f, 1.2f) - wigDrive) * (1f - exp(-dt * 6f))
        if (wigT >= 0f) { wigT += dt; if (wigT > 3f) wigT = -1f }
        val trig = if (wigT >= 0f) exp(-2.0f * wigT) else 0f
        val idle = if (prefs.getBoolean("wigIdle", false)) 0.15f else 0f
        wigAmp = max(max(trig, wigDrive), idle)
        val target = targetHue()
        if (hueCur < 0f) hueCur = target
        else {
            val d = ((target - hueCur + 540f) % 360f) - 180f
            hueCur = (hueCur + d * min(1f, dt * 2f) + 360f) % 360f
        }
        if (jellyT >= 0f) { jellyT += dt; if (jellyT > 2.4f) jellyT = -1f }
        if (animKind != 0) { animT += dt; if (animT > animDur(animKind)) animKind = 0 }
        var i = shocks.size - 1
        while (i >= 0) { shocks[i].t += dt; if (shocks[i].t > 2.2f) shocks.removeAt(i); i-- }
        val sp = 0.2f + prefs.getInt("speed", 50) / 50f
        i = ripples.size - 1
        while (i >= 0) { ripples[i].r += 720f * dt * sp; if (ripples[i].r > 400f) ripples.removeAt(i); i-- }
        i = sparks.size - 1
        while (i >= 0) {
            val s = sparks[i]
            s.x += s.vx * dt; s.y += s.vy * dt; s.vy += 500f * dt; s.life -= dt * 1.6f
            if (s.life <= 0f) sparks.removeAt(i)
            i--
        }
        i = trail.size - 1
        while (i >= 0) { trail[i].age += dt; if (trail[i].age > 0.6f) trail.removeAt(i); i-- }
        if (chargeGlow > 0f) chargeGlow = max(0f, chargeGlow - dt * 0.9f)
    }

    private fun loadBg() {
        val ver = prefs.getLong("bgVer", 0L)
        if (ver == bgVer) return
        bgVer = ver
        bg?.recycle(); bg = null
        val f = File(ctx.filesDir, "bg.jpg")
        if (f.exists()) bg = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Throwable) { null }
    }

    private fun ensureBuf(): Boolean {
        if (buf != null) return true
        return try {
            val b = Bitmap.createBitmap(max(1, (w * bs).toInt()), max(1, (h * bs).toInt()), Bitmap.Config.ARGB_8888)
            buf = b; bufC = Canvas(b); true
        } catch (e: Throwable) { false }
    }

    private fun freeBuf() { buf?.recycle(); buf = null; bufC = null }

    // ---------- композиция (желе, волны, глитч и т.д.) ----------

    private fun composite(c: Canvas) {
        val b = buf ?: return
        val k = inten()
        val wf = w.toFloat()
        val hf = h.toFloat()
        c.save()
        when (animKind) {
            3 -> {
                val p = (animT / 1.0f).coerceIn(0f, 1f)
                val q = 1f - p
                val s = 1f + 0.32f * k * q * q * q
                c.scale(s, s, wf / 2f, hf / 2f)
            }
            5 -> {
                val p = (animT / 0.7f).coerceIn(0f, 1f)
                val s = 1f + 0.06f * k * (1f - p)
                c.scale(s, s, wf / 2f, hf / 2f)
            }
            6 -> {
                val env = exp(-3.2f * animT)
                val ang = 9f * k * env * cos(animT * 13f)
                val rad = Math.toRadians(ang.toDouble()).toFloat()
                val ratio = max(hf / wf, wf / hf)
                val s = cos(rad) + ratio * abs(sin(rad))
                c.rotate(ang, wf / 2f, hf / 2f)
                c.scale(s, s, wf / 2f, hf / 2f)
            }
            9 -> {
                val s = 1f + 0.05f * k * abs(sin(animT * 14f)) * exp(-3.0f * animT)
                c.scale(s, s, wf / 2f, hf / 2f)
            }
        }
        if (animKind == 4) drawGlitch(c, b, k) else drawMesh(c, b, k)
        c.restore()
        if (animKind == 5) {
            val p = (animT / 0.7f).coerceIn(0f, 1f)
            val a = ((1f - p) * (1f - p) * 230f * min(1f, k)).toInt().coerceIn(0, 255)
            c.drawColor(Color.argb(a, 255, 255, 255))
        }
    }

    private fun loadWig() {
        val ver = prefs.getLong("wigVer", 0L)
        if (ver == wigVer) return
        wigVer = ver
        wigMask = null
        val f = File(ctx.filesDir, "wiggle.png")
        if (!f.exists()) return
        try {
            val b = BitmapFactory.decodeFile(f.absolutePath) ?: return
            val px = IntArray(b.width * b.height)
            b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
            wigMW = b.width
            wigMH = b.height
            wigMask = ByteArray(px.size) { (px[it] ushr 24).toByte() }
            b.recycle()
        } catch (e: Throwable) { wigMask = null }
    }

    private fun maskAt(u: Float, v: Float): Float {
        val m = wigMask ?: return 0f
        val fx = (u * (wigMW - 1)).coerceIn(0f, (wigMW - 1).toFloat())
        val fy = (v * (wigMH - 1)).coerceIn(0f, (wigMH - 1).toFloat())
        val x0 = fx.toInt()
        val y0 = fy.toInt()
        val x1 = min(x0 + 1, wigMW - 1)
        val y1 = min(y0 + 1, wigMH - 1)
        val ax = fx - x0
        val ay = fy - y0
        fun g(x: Int, y: Int) = (m[y * wigMW + x].toInt() and 0xFF) / 255f
        val top = g(x0, y0) * (1f - ax) + g(x1, y0) * ax
        val bot = g(x0, y1) * (1f - ax) + g(x1, y1) * ax
        return top * (1f - ay) + bot * ay
    }

    private fun drawMesh(c: Canvas, b: Bitmap, k: Float) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val mw = if (fineMesh) MWF else MW
        val mh = if (fineMesh) MHF else MH
        val edge = wf * 0.08f
        val strength = 0.4f + prefs.getInt("wigStr", 50) / 60f
        val tj = prefs.getInt("tiltJelly", 0) / 100f * wigDrive
        val useWig = fineMesh && wigAmp > 0.01f
        var i = 0
        for (iy in 0..mh) {
            val y = hf * iy / mh
            for (ix in 0..mw) {
                val x = wf * ix / mw
                var dx = 0f
                var dy = 0f
                val wgt = (min(min(x, wf - x), min(y, hf - y)) / edge).coerceIn(0f, 1f)
                if (jellyT >= 0f) {
                    val env = exp(-2.8f * jellyT)
                    dx += 42f * k * env * sin(y * 0.011f - jellyT * 17f) * wgt
                    dy += 34f * k * env * sin(x * 0.014f - jellyT * 21f + 1.3f) * wgt
                }
                if (tj > 0.01f) {
                    dx += 30f * tj * sin(y * 0.011f - t * 13f) * wgt
                    dy += 24f * tj * sin(x * 0.014f - t * 16f + 1.3f) * wgt
                }
                if (useWig) {
                    val mk = maskAt(x / wf, y / hf)
                    if (mk > 0.01f) {
                        val a = mk * wigAmp * strength * wgt
                        val ph = t * 14f
                        dx += 26f * a * sin(y * 0.02f + ph)
                        dy += 22f * a * sin(x * 0.024f + ph * 1.2f + 1f)
                    }
                }
                for (si in shocks.indices) {
                    val s = shocks[si]
                    if (s.t < 0f) continue
                    val rx = x - s.x
                    val ry = y - s.y
                    val r = max(1f, sqrt(rx * rx + ry * ry))
                    val d = r - s.speed * s.t
                    val g = exp(-(d * d) / (2f * 120f * 120f))
                    val push = s.amp * g * exp(-2.0f * s.t)
                    dx += rx / r * push * wgt
                    dy += ry / r * push * wgt
                }
                verts[i++] = x + dx
                verts[i++] = y + dy
            }
        }
        c.drawBitmapMesh(b, mw, mh, verts, 0, null, 0, bufPaint)
    }

    private fun drawGlitch(c: Canvas, b: Bitmap, k: Float) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        fullR.set(0f, 0f, wf, hf)
        c.drawBitmap(b, null, fullR, bufPaint)
        val rnd = Random((animT * 20f).toInt() * 7919 + 13)
        val env = (1f - animT / 0.8f).coerceIn(0f, 1f)
        paint.style = Paint.Style.FILL
        for (i in 0 until 10) {
            val y0 = rnd.nextFloat() * hf
            val y1 = min(hf, y0 + 12f + rnd.nextFloat() * 120f)
            val off = (rnd.nextFloat() - 0.5f) * 160f * k * env
            srcR.set(0, (y0 * bs).toInt(), b.width, min(b.height, (y1 * bs).toInt()))
            if (srcR.height() <= 0) continue
            dstR.set(off, y0, off + wf, y1)
            c.drawBitmap(b, srcR, dstR, bufPaint)
            paint.color = if (i % 2 == 0) Color.argb((90 * env).toInt(), 0, 255, 255)
            else Color.argb((90 * env).toInt(), 255, 0, 128)
            c.drawRect(0f, y0, wf, y1, paint)
        }
    }

    // ---------- сцена ----------

    private fun hsv(hue: Float, s: Float, v: Float, a: Int = 255) =
        Color.HSVToColor(a, floatArrayOf(((hue % 360f) + 360f) % 360f, s, v))

    private fun initParts(effect: Int, count: Int) {
        parts = ArrayList()
        val n = if (effect == 5) max(8, count / 3) else if (effect == 7) max(10, count / 2) else count
        repeat(n) {
            val x = Random.nextFloat() * w
            val y = Random.nextFloat() * h
            val r = Random.nextFloat()
            parts.add(
                when (effect) {
                    0 -> P(x, y, 18f + r * 14f, 20f + Random.nextFloat() * 30f, 0f)
                    1 -> P(x, y, 1.5f + r * 2.5f, 2f + Random.nextFloat() * 4f, Random.nextFloat() * 6.28f)
                    5 -> P(x, y, 0.6f + r * 1.4f, 6f + Random.nextFloat() * 20f, Random.nextFloat() * 6.28f)
                    else -> P(x, y, 0.3f, 1f + r * 2f, Random.nextFloat() * 6.28f)
                }
            )
        }
        heads = FloatArray(max(1, w / 28)) { -Random.nextFloat() * h }
    }

    private fun drawScene(c: Canvas) {
        val sp = 0.2f + prefs.getInt("speed", 50) / 50f
        val f = curDt * 60f
        val hue = hueCur
        val par = prefs.getBoolean("parallax", true)
        val px = if (par) tiltX else 0f
        val py = if (par) tiltY else 0f
        val scroll = if (par) offsetX - 0.5f else 0f
        val wf = w.toFloat()
        val hf = h.toFloat()

        // --- фон ---
        val photo = if (prefs.getInt("bgMode", 0) == 1) bg else null
        if (photo != null) {
            val s = max(wf / photo.width, hf / photo.height) * 1.15f
            val dx = (wf - photo.width * s) / 2f - px * 30f - scroll * 50f
            val dy = (hf - photo.height * s) / 2f - py * 30f
            mat.reset(); mat.postScale(s, s); mat.postTranslate(dx, dy)
            c.drawBitmap(photo, mat, bufPaint)
            c.drawColor(Color.argb(prefs.getInt("dim", 25) * 220 / 100, 0, 0, 0))
        } else {
            paint.style = Paint.Style.FILL
            val ms = if (prefs.getBoolean("mono", false)) 0f else 1f
            // Calm, premium dark wallpaper instead of the old saturated neon gradient.
            paint.shader = LinearGradient(0f, 0f, wf * 0.75f, hf,
                hsv(hue, 0.16f * ms, 0.055f),
                hsv(hue + 28f, 0.24f * ms, 0.17f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, paint)
            paint.shader = null
        }

        // --- основной эффект ---
        val effect = prefs.getInt("effect", 6)
        val count = 20 + prefs.getInt("density", 40) * 3
        val key = "$effect-$count-$w-$h"
        if (key != lastKey) { initParts(effect, count); lastKey = key }
        c.save()
        c.translate(-px * 22f - scroll * 30f, -py * 22f)
        when (effect) {
            0 -> {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f
                paint.color = hsv(hue, 0.2f, 1f, 150)
                for (p in parts) {
                    p.y += p.v * sp * f; p.x -= 3f * sp * f
                    if (p.y > hf) { p.y = -p.r; p.x = Random.nextFloat() * (wf + 100f) }
                    c.drawLine(p.x, p.y, p.x + 3f, p.y + p.r, paint)
                }
            }
            1 -> {
                paint.style = Paint.Style.FILL; paint.color = Color.argb(220, 255, 255, 255)
                for (p in parts) {
                    p.y += p.v * sp * f
                    p.x += sin(t * 2f + p.ph) * 0.8f * f
                    if (p.y > hf + 10f) { p.y = -10f; p.x = Random.nextFloat() * wf }
                    c.drawCircle(p.x, p.y, p.r, paint)
                }
            }
            2 -> {
                paint.style = Paint.Style.FILL
                for (p in parts) {
                    p.y -= p.v * sp * f
                    if (p.y < 0f) { p.y = hf; p.x = Random.nextFloat() * wf }
                    val a = (128 + 127 * sin(t * 3f * sp + p.ph)).toInt()
                    paint.color = hsv(hue, 0.15f, 1f, a)
                    c.drawCircle(p.x, p.y, p.r, paint)
                }
            }
            3 -> {
                paint.style = Paint.Style.FILL
                for (i in 0..3) {
                    val path = Path()
                    path.moveTo(0f, hf)
                    var x = 0f
                    while (x <= wf + 12f) {
                        val y = hf * (0.45f + 0.12f * i) + sin(x * 0.008f + t * sp * (1f + i * 0.35f) + i) * hf * 0.04f
                        path.lineTo(x, y); x += 12f
                    }
                    path.lineTo(wf, hf); path.close()
                    paint.color = hsv(hue + i * 25f, 0.7f, 1f, 90)
                    c.drawPath(path, paint)
                }
            }
            4 -> {
                val size = 28f
                textPaint.typeface = Typeface.MONOSPACE
                textPaint.textAlign = Paint.Align.LEFT
                textPaint.textSize = size
                textPaint.clearShadowLayer()
                for (i in heads.indices) {
                    heads[i] += 6f * sp * f
                    if (heads[i] - 15 * size > hf) heads[i] = -Random.nextFloat() * hf * 0.5f
                    for (k in 0..14) {
                        val y = heads[i] - k * size
                        if (y < 0f || y > hf) continue
                        val idx = (i * 31 + k * 7 + (heads[i] / size).toInt()).mod(chars.size)
                        textPaint.color = if (k == 0) Color.WHITE else hsv(hue, 0.9f, 1f, 255 - k * 17)
                        c.drawText(chars[idx].toString(), i * size, y, textPaint)
                    }
                }
            }
            5 -> {
                for (p in parts) {
                    p.y -= p.v * sp * f * 1.5f
                    p.x += sin(t * 1.5f + p.ph) * 0.6f * f
                    if (p.y < -p.r) { p.y = hf + p.r; p.x = Random.nextFloat() * wf }
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
                    paint.color = hsv(hue, 0.3f, 1f, 110)
                    c.drawCircle(p.x, p.y, p.r, paint)
                    paint.style = Paint.Style.FILL; paint.color = Color.argb(160, 255, 255, 255)
                    c.drawCircle(p.x - p.r * 0.35f, p.y - p.r * 0.35f, max(1.5f, p.r * 0.18f), paint)
                }
            }
            7 -> { // светлячки
                paint.style = Paint.Style.FILL
                for (p in parts) {
                    p.x += sin(t * 0.7f + p.ph) * 0.7f * sp * f
                    p.y += cos(t * 0.5f + p.ph * 1.3f) * 0.5f * sp * f
                    if (p.x < -20f) p.x = wf + 20f else if (p.x > wf + 20f) p.x = -20f
                    if (p.y < -20f) p.y = hf + 20f else if (p.y > hf + 20f) p.y = -20f
                    val a = 0.5f + 0.5f * sin(t * 2f * sp + p.ph * 3f)
                    val col = hsv(hue + p.ph * 20f, 0.55f, 1f, 255) and 0x00FFFFFF
                    paint.color = col or ((a * 28f).toInt() shl 24)
                    c.drawCircle(p.x, p.y, p.r * 5f, paint)
                    paint.color = col or ((a * 70f).toInt() shl 24)
                    c.drawCircle(p.x, p.y, p.r * 2.4f, paint)
                    paint.color = col or ((a * 255f).toInt() shl 24)
                    c.drawCircle(p.x, p.y, p.r, paint)
                }
            }
            8 -> { // аврора
                paint.style = Paint.Style.FILL
                for (i in 0..2) {
                    val base = hf * (0.22f + 0.1f * i)
                    val path = Path()
                    path.moveTo(0f, base + hf * 0.4f)
                    var x = 0f
                    while (x <= wf + 16f) {
                        val y = base + sin(x * 0.006f + t * 0.35f * sp + i * 1.7f) * hf * 0.05f +
                                sin(x * 0.013f - t * 0.22f * sp + i) * hf * 0.025f
                        path.lineTo(x, y); x += 16f
                    }
                    path.lineTo(wf, base + hf * 0.4f); path.close()
                    paint.shader = LinearGradient(0f, base - hf * 0.06f, 0f, base + hf * 0.4f,
                        hsv(hue + i * 45f, 0.7f, 1f, 150), hsv(hue + i * 45f + 30f, 0.7f, 1f, 0), Shader.TileMode.CLAMP)
                    c.drawPath(path, paint)
                }
                paint.shader = null
            }
        }
        c.restore()

        // --- свечение зарядки ---
        if (chargeGlow > 0f) {
            val a = (chargeGlow * 170f).toInt().coerceIn(0, 255)
            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(wf / 2f, hf, hf * 0.8f, hsv(chargeHue, 0.9f, 1f, a), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, paint)
            paint.shader = null
        }

        // --- эффекты касаний ---
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f
        for (r in ripples) {
            paint.color = hsv(hue, 0.3f, 1f, (255 * (1f - r.r / 400f)).toInt().coerceIn(0, 255))
            c.drawCircle(r.x, r.y, r.r, paint)
        }
        paint.style = Paint.Style.FILL
        for (s in sparks) {
            paint.color = hsv(if (s.hue >= 0f) s.hue else hue + 30f, if (s.hue >= 0f) 0.8f else 0.5f, 1f, (255 * s.life).toInt().coerceIn(0, 255))
            c.drawCircle(s.x, s.y, 4f * s.life + 1f, paint)
        }
        paint.style = Paint.Style.STROKE
        for (i in 1 until trail.size) {
            val a = trail[i]
            val b = trail[i - 1]
            val al = (1f - a.age / 0.6f).coerceIn(0f, 1f)
            paint.strokeWidth = 14f; paint.color = hsv(hue, 0.8f, 1f, (90 * al).toInt())
            c.drawLine(b.x, b.y, a.x, a.y, paint)
            paint.strokeWidth = 4f; paint.color = Color.argb((255 * al).toInt(), 255, 255, 255)
            c.drawLine(b.x, b.y, a.x, a.y, paint)
        }

        if (prefs.getBoolean("glint", false)) {
            val gx = wf * (0.5f + tiltX * 0.7f)
            val gy = hf * (0.5f + tiltY * 0.4f)
            val bw = wf * 0.55f
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(gx - bw, gy - bw * 0.6f, gx + bw, gy + bw * 0.6f,
                intArrayOf(0x00FFFFFF, hsv(hue + tiltX * 140f, 0.25f, 1f, 95), 0x00FFFFFF),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, paint)
            paint.shader = null
        }

        if (eggT in 0f..2.4f) {
            val a = (255 * (1f - eggT / 2.4f)).toInt().coerceIn(0, 255)
            textPaint.typeface = Typeface.DEFAULT_BOLD
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = wf * 0.11f
            textPaint.setShadowLayer(26f, 0f, 0f, hsv(t * 90f, 0.8f, 1f))
            textPaint.color = Color.argb(a, 255, 255, 255)
            c.drawText("🍮 FxWall 🍮", wf / 2f, hf * 0.42f - eggT * 40f, textPaint)
            textPaint.clearShadowLayer()
        }

        // --- часы ---
        val clock = prefs.getInt("clock", 0)
        if (clock > 0) drawClock(c, clock == 1, hue, px, py)
    }

    private fun drawClock(c: Canvas, big: Boolean, hue: Float, px: Float, py: Float) {
        val now = Date()
        textPaint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = if (big) w * 0.26f else w * 0.12f
        textPaint.color = Color.WHITE
        textPaint.setShadowLayer(24f, 0f, 0f, hsv(hue, 0.8f, 1f))
        val cx = w / 2f - px * 14f
        val cy = h * (if (big) 0.24f else 0.12f) - py * 14f
        c.drawText(timeFmt.format(now), cx, cy, textPaint)
        textPaint.textSize = w * 0.045f
        c.drawText(dateFmt.format(now), cx, cy + w * 0.075f, textPaint)
        textPaint.clearShadowLayer()
    }
}
