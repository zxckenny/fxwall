package com.fxwall

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    val EFFECTS = listOf("Дождь", "Снег", "Звёзды", "Волны", "Матрица", "Пузыри", "Без эффекта", "Светлячки", "Аврора")
    val UNLOCK = listOf("Выкл", "Желе", "Ударная волна", "Зум-удар", "Глитч", "Вспышка", "Качели", "Случайный", "Рябь", "Пульс")
    val TOUCH = listOf("Выкл", "Круги", "Искры", "Неоновый след", "Волна от касания")
    val COLOR = listOf("Ручной", "По времени суток", "По заряду батареи", "Радуга")
    val CLOCK = listOf("Выкл", "Крупные часы", "Мини-часы")
    val SWIPE_DOWN = listOf("Ничего", "Шторка уведомлений")
    val SORT = listOf("А–Я", "Частые сверху")
    val BG = listOf("Градиент", "Моё фото", "Видео")

    val SHAPE = listOf("Из сета", "Круг", "Сквиркл", "Скруглённый квадрат", "Квадрат", "Без формы")
    val SHAPE_KEYS = listOf("", "circle", "squircle", "rounded", "square", "none")
    val ISTYLE = listOf("Из сета", "Оригинал", "Моно", "Акцент (как Material You)")
    val ISTYLE_KEYS = listOf("", "original", "mono", "accent")
    val WSTYLE = listOf("Из сета", "Nothing (точки)", "iOS (стекло)", "Material You", "Неон", "Aero", "Минимал")
    val WSTYLE_KEYS = listOf("", "dot", "ios", "md3", "neon", "aero", "min")
    val FONT = listOf("Из сета", "Системный", "Моно", "Serif", "Light", "Condensed", "Свой (.ttf)")
    val FONT_KEYS = listOf("", "sans-serif", "monospace", "serif", "sans-serif-light", "sans-serif-condensed", "custom")
    val LAUNCH_ANIM = listOf("Масштаб", "Затухание", "Без анимации")
    val DRAWER_ANIM = listOf("Выезд снизу", "Масштаб + затухание", "Затухание")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
}
