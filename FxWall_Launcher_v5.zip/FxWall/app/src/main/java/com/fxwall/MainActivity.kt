package com.fxwall

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import org.json.JSONObject
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var content: LinearLayout
    private var bgSpinner: Spinner? = null
    private var pad = 0
    private var tab = 0
    private var previewRef: PreviewView? = null
    private var eggTaps = 0
    private var eggLast = 0L
    private var section: LinearLayout? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = Prefs.sp(this)
        pad = (18 * resources.displayMetrics.density).toInt()
        window.statusBarColor = Color.rgb(12, 15, 22)
        window.navigationBarColor = Color.rgb(12, 15, 22)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
            setBackgroundColor(Color.rgb(12, 15, 22))
        }
        val title = TextView(this).apply {
            text = "FxWall"
            textSize = 32f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            letterSpacing = -0.03f
        }
        title.setOnClickListener {
            val now = System.currentTimeMillis()
            eggTaps = if (now - eggLast < 1200) eggTaps + 1 else 1
            eggLast = now
            title.animate().scaleX(0.94f).scaleY(0.94f).setDuration(60).withEndAction {
                title.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
            if (eggTaps >= 7) { eggTaps = 0; unlockEgg(title) }
        }
        outer.addView(title)
        outer.addView(TextView(this).apply {
            text = "Персонализация рабочего стола"
            textSize = 13f
            setTextColor(0xFF9AA6B8.toInt())
            setPadding(0, 0, 0, pad)
        })
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0xFF1B2230.toInt(), 22f)
            setPadding(4, 4, 4, 4)
        }
        listOf("Обои", "Сеты", "Лаунчер").forEachIndexed { i, n ->
            tabs.addView(TextView(this).apply {
                text = n; textSize = 13f; gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(Color.WHITE); setPadding(4, pad / 2, 4, pad / 2)
                background = rounded(if (i == intent.getIntExtra("tab", 0)) 0xFF536DFE.toInt() else Color.TRANSPARENT, 18f)
                setOnClickListener { show(i); for (j in 0 until tabs.childCount) (tabs.getChildAt(j) as TextView).background = rounded(if (j == i) 0xFF536DFE.toInt() else Color.TRANSPARENT, 18f) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(tabs)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, pad / 2, 0, pad * 3)
        }
        outer.addView(ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
        show(intent.getIntExtra("tab", 0))
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius * resources.displayMetrics.density
    }

    private fun target(): LinearLayout = section ?: content

    private fun unlockEgg(title: View) {
        sp.edit().putBoolean("egg", true).apply()
        title.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        ObjectAnimator.ofFloat(title, View.ROTATION, 0f, -8f, 8f, -5f, 5f, 0f).setDuration(650).start()
        previewRef?.fx?.trigger(1)
        toast("🍮 Секрет открыт! Загляни во вкладку «Сеты»")
        if (tab == 1) show(1)
    }

    private fun show(t: Int) {
        tab = t
        section = null
        content.removeAllViews()
        bgSpinner = null
        previewRef = null
        content.alpha = 0f
        content.translationY = 24f * resources.displayMetrics.density
        content.animate().alpha(1f).translationY(0f).setDuration(260)
            .setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
        when (t) {
            0 -> wallTab()
            1 -> setsTab()
            else -> launcherTab()
        }
    }

    // ================= вкладка ОБОИ =================

    private fun wallTab() {
        val d = resources.displayMetrics.density
        val preview = PreviewView(this)
        previewRef = preview
        content.addView(preview, LinearLayout.LayoutParams(-1, (280 * d).toInt()).apply { topMargin = pad })
        button("▶ Тест эффекта разблокировки") {
            val k = sp.getInt("unlock", 1)
            preview.fx.trigger(if (k == 0) 1 else k)
        }
        button("Установить как обои") {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, EffectWallpaperService::class.java)
                )
            )
        }

        header("Фон")
        bgSpinner = spinner("Тип фона", "bgMode", Prefs.BG, 0)
        button("Выбрать фото") { pick("image/*", 1) }
        seekRange("Затемнение фото", "dim", 0, 100, 25)

        header("Видеообои")
        button("Выбрать видео") { pick("video/*", 2) }
        switch("Звук видео", "vsound", false)
        seekRange("Скорость видео (50 = обычная)", "vspeed", 0, 100, 50)
        text("Видео показывается только на самих обоях (в превью его нет). Эффекты частиц и анимации разблокировки в режиме видео не работают.", 12f)

        header("Wiggle и желе (как в OriginOS 7)")
        button("✎ Нарисовать область Wiggle") { startActivity(Intent(this, WiggleActivity::class.java)) }
        button("▶ Тест Wiggle") { preview.fx.wiggle() }
        switch("Wiggle включён (нужна нарисованная область)", "wigOn", false)
        seekRange("Сила Wiggle", "wigStr", 0, 100, 50)
        switch("Постоянное лёгкое покачивание (тратит батарею)", "wigIdle", false)
        seekRange("Желе от наклона телефона", "tiltJelly", 0, 100, 0)
        switch("Блик при наклоне (Glint)", "glint", false)
        switch("Вибро при желе-эффектах", "wallVib", false)

        header("Эффект обоев")
        spinner("Эффект", "effect", Prefs.EFFECTS, 6)
        seekRange("Скорость", "speed", 0, 100, 50)
        seekRange("Количество частиц", "density", 0, 100, 40)

        header("Цвет")
        spinner("Режим цвета", "colorMode", Prefs.COLOR, 0)
        seekRange("Оттенок (ручной режим)", "hue", 0, 360, 210)

        header("Экран: разблокировка и включение")
        spinner("При разблокировке (код / отпечаток / лицо)", "unlock", Prefs.UNLOCK, 1)
        spinner("При включении экрана", "screenOn", Prefs.UNLOCK, 0)
        seekRange("Сила анимации", "uInt", 0, 100, 50)

        header("Касания и движение")
        spinner("Эффект касания", "touch", Prefs.TOUCH, 1)
        switch("Двойной тап — желе", "dtap", true)
        switch("Встряхни телефон — желе", "shake", true)
        switch("Параллакс (наклон + прокрутка рабочих столов)", "parallax", true)

        header("Прочее")
        spinner("Часы на обоях", "clock", Prefs.CLOCK, 0)
        switch("Волна и свечение при подключении зарядки", "chargeFx", true)
        switch("Экономия батареи (30 к/с)", "eco", false)
    }

    // ================= вкладка СЕТЫ =================

    private fun setsTab() {
        val cur = Sets.current(this)
        text("Сет меняет шрифт, форму и стиль иконок, виджеты, цвета и пресет обоев. Действует в лаунчере FxWall и на обоях.", 13f)
        header("Готовые сеты")
        for (s in Sets.all(this)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, pad / 2, 0, pad / 2)
            }
            val sw = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(s.bg, s.surface, s.accent))
                    .apply { cornerRadius = pad.toFloat() }
            }
            row.addView(sw, LinearLayout.LayoutParams(pad * 4, pad * 3))
            row.addView(TextView(this).apply {
                text = (if (s.id == cur.id) "✓ " else "") + s.name
                textSize = 17f; setPadding(pad, 0, pad, 0)
                typeface = if (s.id == cur.id) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Применить"
                setOnClickListener {
                    Sets.apply(this@MainActivity, s)
                    toast("Сет «${s.name}» применён")
                    show(1)
                }
            })
            target().addView(row)
        }

        header("Загрузка и экспорт")
        button("Импорт сета (.json)") { pick("*/*", 3) }
        button("Экспорт текущего сета (поделиться)") {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Sets.current(this).toJson()),
                "Экспорт сета"))
        }
        text("Экспорт даёт готовый шаблон: отредактируй цвета, шрифт, форму иконок и загрузи обратно файлом .json.", 12f)

        header("Шрифт")
        button("Загрузить свой шрифт (.ttf)") { pick("*/*", 4) }
        text("После загрузки выбери «Свой (.ttf)» во вкладке «Лаунчер» → Шрифт.", 12f)

        header("Material You")
        switch("Динамические цвета Material You поверх любого сета (Android 12+)", "dyn", false)
        switch("Светлая тема для Material You", "dynLight", false)

        header("Авто-смена сета (день / ночь)")
        switch("Включить авто-смену", "autoSet", false)
        spinner("Днём", "setDayIdx", Sets.all(this).map { it.name }, 0)
        spinner("Ночью", "setNightIdx", Sets.all(this).map { it.name }, 0)
        seekRange("Ночь начинается в (час)", "nightFrom", 0, 23, 21)
        seekRange("Ночь заканчивается в (час)", "nightTo", 0, 23, 7)
    }

    // ================= вкладка ЛАУНЧЕР =================

    private fun launcherTab() {
        text("FxWall — это ещё и лаунчер: свой рабочий стол, док, список приложений и виджеты.", 13f)
        button("Сделать FxWall лаунчером по умолчанию") {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        header("Анимации")
        seekRange("Скорость анимаций (0 = выкл · 50 = обычно · 100 = ×3)", "animSpeed", 0, 100, 50)
        seekRange("Пружинистость (0 = мягко, 100 = желейно)", "bounce", 0, 100, 50)
        spinner("Открытие приложения", "launchAnim", Prefs.LAUNCH_ANIM, 0)
        spinner("Открытие списка приложений", "drawerAnim", Prefs.DRAWER_ANIM, 0)

        header("Сетка и иконки")
        seekRange("Колонок на рабочем столе", "hcols", 3, 6, 4)
        seekRange("Колонок в списке приложений", "dcols", 3, 6, 4)
        seekRange("Размер иконок, %", "iconSize", 60, 140, 100)
        seekRange("Размер подписей, %", "labelSize", 60, 140, 100)
        switch("Подписи под иконками", "labels", true)
        spinner("Форма иконок", "ovShape", Prefs.SHAPE, 0)
        spinner("Стиль иконок", "ovStyle", Prefs.ISTYLE, 0)
        button("Набор иконок (Nova / ADW)") {
            val packs = IconPack.installed(this)
            if (packs.isEmpty()) toast("Наборы иконок не найдены. Установи любой набор формата Nova/ADW из магазина.")
            else {
                val names = arrayOf("Без набора") + packs.map { it.second }
                AlertDialog.Builder(this).setTitle("Набор иконок").setItems(names) { _, w ->
                    sp.edit().putString("iconPack", if (w == 0) "" else packs[w - 1].first).apply()
                }.show()
            }
        }

        header("Вид")
        spinner("Шрифт", "ovFont", Prefs.FONT, 0)
        spinner("Стиль виджетов", "ovWidget", Prefs.WSTYLE, 0)
        seekRange("Закругление виджетов, dp (0 = из сета)", "ovRadius", 0, 48, 0)

        header("Поведение")
        switch("Показывать нижний док", "showDock", false)
        text("Если выключить док, его приложения останутся среди значков рабочего стола.", 12f)
        spinner("Сортировка списка приложений", "sort", Prefs.SORT, 0)
        switch("Вибро-отклик в лаунчере", "haptic", true)
        switch("Размытие фона при открытии списка (Android 12+)", "blur", true)
        switch("Плавное появление рабочего стола", "intro", true)
        spinner("Свайп вниз по рабочему столу", "swipeDown", Prefs.SWIPE_DOWN, 0)
        button("Скрытые приложения") { hiddenDialog() }
        switch("Поиск в списке приложений", "search", true)
        switch("Свайп вверх — список приложений", "swipeUp", true)
        text("Долгое нажатие на пустое место рабочего стола: виджеты, сеты, обои, настройки.", 12f)

        header("Резервная копия настроек")
        button("Экспорт настроек (поделиться)") {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, exportAll()),
                "Экспорт настроек"))
        }
        button("Импорт настроек (.json)") { pick("*/*", 5) }
    }

    private fun hiddenDialog() {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { ComponentName(it.activityInfo.packageName, it.activityInfo.name).flattenToString() to it.loadLabel(pm).toString() }
            .sortedBy { it.second.lowercase() }
        val hidden = (sp.getString("hidden", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
        val checked = BooleanArray(list.size) { hidden.contains(list[it].first) }
        AlertDialog.Builder(this).setTitle("Скрытые приложения")
            .setMultiChoiceItems(list.map { it.second }.toTypedArray(), checked) { _, i, c ->
                if (c) hidden.add(list[i].first) else hidden.remove(list[i].first)
            }
            .setPositiveButton("Готово") { _, _ -> sp.edit().putString("hidden", hidden.joinToString(",")).apply() }
            .setNegativeButton("Отмена", null).show()
    }

    private fun exportAll(): String {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            if (k.startsWith("u:") || k == "bgVer" || k == "vidVer" || k == "wigVer") continue
            when (v) {
                is Boolean, is Int, is Long, is String -> o.put(k, v)
                else -> {}
            }
        }
        return o.toString(2)
    }

    private fun importAll(txt: String): Boolean = try {
        val o = JSONObject(txt)
        val ed = sp.edit()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k == "bgVer" || k == "vidVer" || k == "wigVer") continue
            when (val v = o.get(k)) {
                is Boolean -> ed.putBoolean(k, v)
                is Int -> ed.putInt(k, v)
                is Long -> ed.putLong(k, v)
                is String -> ed.putString(k, v)
                else -> {}
            }
        }
        ed.apply()
        true
    } catch (e: Exception) { false }

    // ================= элементы UI =================

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun text(s: String, size: Float) = target().addView(TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFF9EABBE.toInt())
        setPadding(0, pad / 3, 0, pad / 2); typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    })

    private fun header(s: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF171E2A.toInt(), 22f)
            setPadding(pad, pad / 2, pad, pad)
        }
        section = box
        content.addView(TextView(this).apply {
            text = s; textSize = 17f; typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE); setPadding(0, pad, 0, pad / 3)
        })
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = pad / 2 })
    }

    private fun button(s: String, onClick: () -> Unit) = target().addView(TextView(this).apply {
        text = s; textSize = 14f; gravity = Gravity.CENTER_VERTICAL
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(Color.WHITE); setPadding(pad, pad / 2, pad, pad / 2)
        background = rounded(0xFF29364C.toInt(), 15f)
        setOnClickListener { onClick() }
        press(this)
    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad / 3 })

    private fun press(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    x.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun spinner(label: String, key: String, items: List<String>, def: Int): Spinner {
        target().addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(0xFFB9C5D6.toInt()); setPadding(0, pad / 2, 0, 4) })
        val s = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sp.getInt(key, def).coerceIn(items.indices))
            setPadding(pad / 2, 0, pad / 2, 0)
            background = rounded(0xFF222C3B.toInt(), 13f)
            setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { sp.edit().putInt(key, pos).apply() }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            })
        }
        target().addView(s, LinearLayout.LayoutParams(-1, (48 * resources.displayMetrics.density).toInt()))
        return s
    }

    private fun seekRange(label: String, key: String, min: Int, max: Int, def: Int) {
        val current = sp.getInt(key, def).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$label  ·  $current"; textSize = 13f; setTextColor(0xFFE5EAF2.toInt()); setPadding(0, pad / 2, 0, 0) }
        target().addView(tv)
        target().addView(SeekBar(this).apply {
            this.max = max - min; progress = current - min
            progressTintList = android.content.res.ColorStateList.valueOf(0xFF8295FF.toInt())
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFB9C4FF.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sp.edit().putInt(key, p + min).apply(); tv.text = "$label  ·  ${p + min}" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun switch(label: String, key: String, def: Boolean) = target().addView(Switch(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE)
        isChecked = sp.getBoolean(key, def)
        setPadding(0, pad / 3, 0, pad / 3)
        setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(key, v).apply() }
    })

    // ================= выбор файлов =================

    private fun pick(mime: String, req: Int) {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime), req)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        Thread {
            var msg = ""
            var ok = false
            when (req) {
                1 -> { ok = savePhoto(uri); msg = if (ok) "Фото установлено как фон" else "Не удалось загрузить фото" }
                2 -> {
                    ok = copyTo(uri, File(filesDir, "bg.mp4"))
                    if (ok) sp.edit().putLong("vidVer", System.currentTimeMillis()).putInt("bgMode", 2).apply()
                    msg = if (ok) "Видео загружено. Установи FxWall как обои" else "Не удалось загрузить видео"
                }
                3 -> {
                    val txt = try { contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() } } catch (e: Exception) { "" }
                    val s = Sets.importJson(this, txt)
                    ok = s != null
                    msg = if (s != null) "Сет «${s.name}» импортирован" else "Это не файл сета (.json)"
                }
                5 -> {
                    val txt = try { contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() } } catch (e: Exception) { "" }
                    ok = importAll(txt)
                    msg = if (ok) "Настройки загружены" else "Это не файл настроек (.json)"
                }
                4 -> {
                    val f = File(filesDir, "font.ttf")
                    ok = copyTo(uri, f) && try { Typeface.createFromFile(f); true } catch (e: Exception) { false }
                    if (ok) sp.edit().putInt("ovFont", 6).apply() else f.delete()
                    msg = if (ok) "Шрифт загружен и включён" else "Не удалось загрузить шрифт"
                }
            }
            runOnUiThread {
                toast(msg)
                if (ok && req == 1 || ok && req == 2) bgSpinner?.setSelection(if (req == 1) 1 else 2)
                if (ok && (req == 3 || req == 4)) show(tab)
            }
        }.start()
    }

    private fun copyTo(uri: Uri, dest: File): Boolean = try {
        contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        true
    } catch (e: Throwable) { false }

    private fun savePhoto(uri: Uri): Boolean {
        return try {
            val o1 = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o1) }
            var sample = 1
            while (max(o1.outWidth, o1.outHeight) / sample > 2400) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
            val orient = try {
                contentResolver.openInputStream(uri)!!.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val m = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            }
            val big = max(bmp.width, bmp.height)
            val sc = if (big > 1800) 1800f / big else 1f
            m.postScale(sc, sc)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            sp.edit().putLong("bgVer", System.currentTimeMillis()).putInt("bgMode", 1).apply()
            true
        } catch (e: Throwable) { false }
    }
}
