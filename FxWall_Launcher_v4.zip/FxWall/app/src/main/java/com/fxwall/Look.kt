package com.fxwall

import android.animation.TimeInterpolator
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.TextUtils
import android.util.Xml
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.xmlpull.v1.XmlPullParser
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sqrt
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

class Spring(private val zeta: Float, private val omega: Float) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        val wd = omega * sqrt(1f - zeta * zeta)
        val e = exp(-zeta * omega * t)
        return 1f - e * (cos(wd * t) + (zeta * omega / wd) * sin(wd * t))
    }
}

class Palette(val bg: Int, val surface: Int, val text: Int, val accent: Int, val dark: Boolean)

class AppEntry(val cn: ComponentName, val label: String) {
    val key: String get() = cn.flattenToString()
}

/** Итоговый внешний вид: сет + пользовательские переопределения + Material You. */
class Look(val ctx: Context) {
    private val sp = Prefs.sp(ctx)
    private val density = ctx.resources.displayMetrics.density
    val set: FxSet = Sets.current(ctx)
    val pal: Palette = resolvePalette()
    val font: Typeface = resolveFont()
    val shape: String = pick("ovShape", Prefs.SHAPE_KEYS, set.shape)
    val style: String = pick("ovStyle", Prefs.ISTYLE_KEYS, set.style)
    val widget: String = pick("ovWidget", Prefs.WSTYLE_KEYS, set.widget)
    val radiusDp: Int = sp.getInt("ovRadius", 0).let { if (it > 0) it else set.radius }
    val animOn: Boolean = sp.getInt("animSpeed", 50) > 0
    val anim: Float = sp.getInt("animSpeed", 50).let { if (it <= 50) 0.25f + 0.75f * it / 50f else 1f + 2f * (it - 50) / 50f }
    val iconPx: Int = (56f * density * sp.getInt("iconSize", 100) / 100f).toInt()
    val labelSp: Float = 11f * sp.getInt("labelSize", 100) / 100f
    val showLabels: Boolean = sp.getBoolean("labels", true)
    val bounce: Float = sp.getInt("bounce", 50) / 100f
    val emphasized: TimeInterpolator = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    /** Затухающая пружина: bounce 0 = мягко без отскока, 1 = желейно. */
    fun spring(): TimeInterpolator = Spring(0.95f - 0.6f * bounce, 11f)
    val pack: IconPack? = sp.getString("iconPack", "")?.takeIf { it.isNotEmpty() }?.let { IconPack.load(ctx, it) }
    private val cache = HashMap<String, Bitmap>()

    private fun pick(key: String, keys: List<String>, def: String): String {
        val i = sp.getInt(key, 0)
        return if (i in 1 until keys.size) keys[i] else def
    }

    private fun resolvePalette(): Palette {
        val dyn = set.dynamic || sp.getBoolean("dyn", false)
        if (dyn && Build.VERSION.SDK_INT >= 31) {
            fun col(id: Int) = ctx.getColor(id)
            return if (!sp.getBoolean("dynLight", false))
                Palette(col(android.R.color.system_neutral1_900), col(android.R.color.system_neutral2_800),
                    col(android.R.color.system_neutral1_50), col(android.R.color.system_accent1_200), true)
            else
                Palette(col(android.R.color.system_neutral1_50), col(android.R.color.system_accent2_100),
                    col(android.R.color.system_neutral1_900), col(android.R.color.system_accent1_600), false)
        }
        return Palette(set.bg, set.surface, set.text, set.accent, set.dark)
    }

    private fun resolveFont(): Typeface {
        val k = pick("ovFont", Prefs.FONT_KEYS, set.font)
        if (k == "custom") {
            val f = File(ctx.filesDir, "font.ttf")
            if (f.exists()) try { return Typeface.createFromFile(f) } catch (e: Exception) {}
            return Typeface.DEFAULT
        }
        return Typeface.create(k, Typeface.NORMAL)
    }

    fun dp(v: Float): Int = (v * density).toInt()
    fun dp(v: Int): Int = dp(v.toFloat())
    fun dur(base: Long): Long = if (!animOn) 0L else (base / anim).toLong()

    fun icon(app: AppEntry): Bitmap = cache.getOrPut(app.key) {
        val pm = ctx.packageManager
        val pd = pack?.get(app.cn)
        if (pd != null) Icons.render(pd, iconPx, "none", "original", pal)
        else {
            val dr = try { pm.getActivityIcon(app.cn) } catch (e: Exception) { pm.defaultActivityIcon }
            Icons.render(dr, iconPx, shape, style, pal)
        }
    }
}

object Icons {
    private fun path(shape: String, s: Float): Path {
        val p = Path()
        when (shape) {
            "circle" -> p.addOval(0f, 0f, s, s, Path.Direction.CW)
            "rounded" -> p.addRoundRect(0f, 0f, s, s, s * 0.22f, s * 0.22f, Path.Direction.CW)
            "square" -> p.addRoundRect(0f, 0f, s, s, s * 0.06f, s * 0.06f, Path.Direction.CW)
            else -> {
                val r = s / 2f
                for (i in 0..72) {
                    val t = i * 2.0 * Math.PI / 72
                    val cs = cos(t).toFloat()
                    val sn = sin(t).toFloat()
                    val x = r + r * sign(cs) * abs(cs).pow(0.5f)
                    val y = r + r * sign(sn) * abs(sn).pow(0.5f)
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }

    fun render(d: Drawable, px: Int, shape: String, style: String, pal: Palette): Bitmap {
        var bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = px.toFloat()
        if (shape == "none") {
            d.setBounds(0, 0, px, px)
            d.draw(c)
        } else {
            if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
                val o = (s * 0.25f).toInt()
                if (style == "accent") {
                    c.drawColor(pal.surface)
                    d.foreground?.let {
                        it.colorFilter = PorterDuffColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
                        it.setBounds(-o, -o, px + o, px + o); it.draw(c)
                    }
                } else {
                    d.background?.let { it.setBounds(-o, -o, px + o, px + o); it.draw(c) }
                    d.foreground?.let { it.setBounds(-o, -o, px + o, px + o); it.draw(c) }
                }
            } else {
                c.drawColor(if (pal.dark) pal.surface else Color.WHITE)
                val i = (s * 0.14f).toInt()
                d.setBounds(i, i, px - i, px - i)
                d.draw(c)
            }
            // обрезка по форме со сглаживанием: чистим всё снаружи
            val inv = path(shape, s)
            inv.fillType = Path.FillType.INVERSE_WINDING
            val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
            c.drawPath(inv, clear)
        }
        if (style == "mono") {
            val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
            }
            Canvas(out).drawBitmap(bmp, 0f, 0f, pt)
            bmp = out
        }
        return bmp
    }
}

/** Поддержка наборов иконок формата Nova / ADW (appfilter.xml). */
class IconPack private constructor(private val res: Resources, private val pkg: String) {
    private val map = HashMap<String, String>()

    fun get(cn: ComponentName): Drawable? {
        val name = map[cn.toString()] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try { res.getDrawable(id, null) } catch (e: Exception) { null }
    }

    private fun parse() {
        val id = res.getIdentifier("appfilter", "xml", pkg)
        if (id != 0) { read(res.getXml(id)); return }
        try {
            val p = Xml.newPullParser()
            p.setInput(res.assets.open("appfilter.xml"), "utf-8")
            read(p)
        } catch (e: Exception) {}
    }

    private fun read(p: XmlPullParser) {
        var e = p.eventType
        while (e != XmlPullParser.END_DOCUMENT) {
            if (e == XmlPullParser.START_TAG && p.name == "item") {
                val comp = p.getAttributeValue(null, "component")
                val dr = p.getAttributeValue(null, "drawable")
                if (comp != null && dr != null) map.putIfAbsent(comp, dr)
            }
            e = p.next()
        }
    }

    companion object {
        fun load(ctx: Context, pkg: String): IconPack? = try {
            val p = IconPack(ctx.packageManager.getResourcesForApplication(pkg), pkg)
            p.parse()
            if (p.map.isEmpty()) null else p
        } catch (e: Exception) { null }

        fun installed(ctx: Context): List<Pair<String, String>> {
            val pm = ctx.packageManager
            val out = LinkedHashMap<String, String>()
            for (a in listOf("org.adw.launcher.THEME", "com.novalauncher.THEME"))
                for (ri in pm.queryIntentActivities(Intent(a), 0))
                    out[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
            return out.map { it.key to it.value }
        }
    }
}

/** Ячейка приложения: иконка + подпись. Используется на рабочем столе, в доке и в списке. */
class Cell(ctx: Context, private val look: Look, onWall: Boolean, labels: Boolean) : LinearLayout(ctx) {
    private val img = ImageView(ctx)
    private val lbl = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(look.dp(2), look.dp(8), look.dp(2), look.dp(6))
        addView(img, LayoutParams(look.iconPx, look.iconPx))
        lbl.textSize = look.labelSp
        lbl.typeface = look.font
        lbl.maxLines = 1
        lbl.ellipsize = TextUtils.TruncateAt.END
        lbl.gravity = Gravity.CENTER
        lbl.setPadding(0, look.dp(4), 0, 0)
        lbl.setTextColor(if (onWall) Color.WHITE else look.pal.text)
        if (onWall) lbl.setShadowLayer(6f, 0f, 2f, 0xAA000000L.toInt())
        lbl.visibility = if (labels && look.showLabels) VISIBLE else GONE
        addView(lbl, LayoutParams(-2, -2))
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(look.dur(110))
                        .setInterpolator(look.emphasized).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(look.dur(520))
                        .setInterpolator(look.spring()).start()
            }
            false
        }
    }

    fun bind(app: AppEntry) {
        img.setImageBitmap(look.icon(app))
        lbl.text = app.label
    }
}
