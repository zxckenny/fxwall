package com.fxwall

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class HomeActivity : Activity() {
    private val reqBind = 11
    private val reqConf = 12
    private lateinit var sp: SharedPreferences
    private lateinit var look: Look
    private lateinit var rootV: FrameLayout
    private lateinit var homeScroll: ScrollView
    private lateinit var widgetBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var adapter: AppAdapter
    private var pinBoxV: LinearLayout? = null
    private var dockV: View? = null
    private var apps: List<AppEntry> = emptyList()
    private var ordered: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private var byKey: Map<String, AppEntry> = emptyMap()
    private var drawerOpen = false
    private var drawerP = 0f
    private var drawerAnim: ValueAnimator? = null
    private var pendingId = -1
    private var insetTop = 0
    private var insetBottom = 0
    private var playIntro = false
    private var dragging = false
    private var dragFromOpen = false
    private var armed = false
    private var downX = 0f
    private var downY = 0f
    private var vt: VelocityTracker? = null
    private val host by lazy { AppWidgetHost(this, 1024) }
    private val awm: AppWidgetManager by lazy { AppWidgetManager.getInstance(this) }

    private val pkgRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!::look.isInitialized) return
            loadApps(); setContentView(buildUi())
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = Prefs.sp(this)
        if (sp.getString("dockApps", null) == null) {
            val legacy = try { sp.getString("dock", null) } catch (e: Exception) { null }
            if (!legacy.isNullOrBlank()) sp.edit().putString("dockApps", legacy).apply()
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onStart() {
        super.onStart()
        playIntro = true
        try { host.startListening() } catch (e: Exception) {}
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgRcv, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(pkgRcv, f)
    }

    override fun onStop() {
        try { host.stopListening() } catch (e: Exception) {}
        try { unregisterReceiver(pkgRcv) } catch (e: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        look = Look(this)
        loadApps()
        setContentView(buildUi())
        if (playIntro) {
            playIntro = false
            if (sp.getBoolean("intro", true)) introAnim()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
        if (::homeScroll.isInitialized) homeScroll.smoothScrollTo(0, 0)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
    }

    // ---------- жесты: шторка тянется за пальцем ----------

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!::drawer.isInitialized || !::homeScroll.isInitialized) return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY; dragging = false
                armed = if (drawerOpen) !grid.canScrollVertically(-1)
                else sp.getBoolean("swipeUp", true) && !homeScroll.canScrollVertically(1)
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && armed && abs(dy) > slop * 2 && abs(dy) > abs(dx) * 1.3f &&
                    ((!drawerOpen && dy < 0f) || (drawerOpen && dy > 0f))) {
                    dragging = true
                    dragFromOpen = drawerOpen
                    val old = drawerAnim; drawerAnim = null; old?.cancel()
                    if (!drawerOpen) prepareDrawer()
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                }
                if (dragging) {
                    val h = max(1f, rootV.height * 0.7f)
                    setDrawerProgress(if (dragFromOpen) 1f - dy / h else -dy / h)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(ev)
                if (dragging) {
                    dragging = false
                    vt?.computeCurrentVelocity(1000)
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle(); vt = null
                    val open = if (abs(vy) > 900f) vy < 0f else drawerP > 0.45f
                    if (open) { drawerOpen = true; tick(null); animateDrawer(1f) }
                    else { drawerOpen = false; hideKeyboard(); animateDrawer(0f) }
                    return true
                }
                vt?.recycle(); vt = null
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ---------- данные ----------

    private fun loadApps() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(i, 0)
            .map { AppEntry(ComponentName(it.activityInfo.packageName, it.activityInfo.name), it.loadLabel(pm).toString()) }
            .sortedBy { it.label.lowercase() }
        byKey = apps.associateBy { it.key }
        ordered = sortedApps()
        shown = ordered
    }

    private fun sortedApps(): List<AppEntry> =
        if (sp.getInt("sort", 0) == 1)
            apps.sortedWith(compareByDescending<AppEntry> { sp.getInt("u:" + it.key, 0) }.thenBy { it.label.lowercase() })
        else apps

    private fun tokens(key: String, def: List<String>): List<String> =
        sp.getString(key, null)?.split(",")?.filter { it.isNotBlank() } ?: def

    private fun saveTokens(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString(",")).apply()
    }

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        return intents.mapNotNull { i ->
            packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo
                ?.let { ComponentName(it.packageName, it.name).flattenToString() }
        }
    }

    private fun tick(v: View?, type: Int = HapticFeedbackConstants.VIRTUAL_KEY) {
        if (sp.getBoolean("haptic", true)) (v ?: window.decorView).performHapticFeedback(type)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
    }

    // ---------- UI ----------

    private fun buildUi(): View {
        val old = drawerAnim; drawerAnim = null; old?.cancel()
        drawerP = 0f; drawerOpen = false; dragging = false
        val pal = look.pal
        val r = FrameLayout(this)
        rootV = r
        val dockOn = sp.getBoolean("showDock", false)

        homeScroll = ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER; clipToPadding = false
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(look.dp(14), look.dp(14), look.dp(14), look.dp(if (dockOn) 120 else 24))
            setOnLongClickListener { tick(this, HapticFeedbackConstants.LONG_PRESS); homeMenu(); true }
        }
        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(widgetBox)
        fillWidgets()
        col.addView(pinGrid())
        homeScroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        r.addView(homeScroll, FrameLayout.LayoutParams(-1, -1))

        dockV = null
        if (dockOn) {
            val dv = dockView()
            dockV = dv
            r.addView(dv, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                setMargins(look.dp(12), 0, look.dp(12), look.dp(10))
            })
        }

        // список приложений
        val blurOn = Build.VERSION.SDK_INT >= 31 && sp.getBoolean("blur", true)
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(if (blurOn) 0xB8 else 0xF0, Color.red(pal.bg), Color.green(pal.bg), Color.blue(pal.bg)))
            visibility = View.GONE
            isClickable = true
        }
        search = EditText(this).apply {
            hint = "Поиск приложений"
            typeface = look.font
            isSingleLine = true
            setTextColor(pal.text)
            setHintTextColor((pal.text and 0x00FFFFFF) or 0x88000000.toInt())
            background = GradientDrawable().apply { setColor(pal.surface); cornerRadius = look.dp(24f).toFloat() }
            setPadding(look.dp(18), look.dp(12), look.dp(18), look.dp(12))
            visibility = if (sp.getBoolean("search", true)) View.VISIBLE else View.GONE
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString()?.trim().orEmpty()
                    shown = if (q.isEmpty()) ordered else ordered.filter { it.label.contains(q, true) }
                    adapter.notifyDataSetChanged()
                    when (q.lowercase()) {
                        "желе", "jelly" -> jellyEgg()
                        "fxwall" -> aboutEgg()
                        else -> {}
                    }
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        grid = GridView(this).apply {
            numColumns = sp.getInt("dcols", 4)
            verticalSpacing = look.dp(4)
            selector = ColorDrawable(0)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, look.dp(8), 0, look.dp(24))
        }
        adapter = AppAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, v, p, _ -> launch(shown[p], v) }
        grid.setOnItemLongClickListener { _, v, p, _ -> menu(shown[p], v); true }
        drawer.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = look.dp(6) })
        drawer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        r.addView(drawer, FrameLayout.LayoutParams(-1, -1))

        r.setOnApplyWindowInsetsListener { _, ins ->
            insetTop = ins.systemWindowInsetTop
            insetBottom = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        applyInsets()
        setDrawerProgress(0f)
        r.post { r.requestApplyInsets() }
        return r
    }

    private fun applyInsets() {
        homeScroll.setPadding(0, insetTop, 0, insetBottom)
        drawer.setPadding(look.dp(10), insetTop + look.dp(14), look.dp(10), insetBottom)
        val lp = dockV?.layoutParams as? FrameLayout.LayoutParams
        if (lp != null) { lp.bottomMargin = insetBottom + look.dp(10); dockV?.layoutParams = lp }
    }

    private fun cell(a: AppEntry, onWall: Boolean, labels: Boolean): Cell {
        val c = Cell(this, look, onWall, labels)
        c.bind(a)
        c.setOnClickListener { launch(a, c) }
        c.setOnLongClickListener { menu(a, c); true }
        return c
    }

    private fun pinGrid(): View {
        val cols = sp.getInt("hcols", 4)
        val list = tokens("pins", emptyList()).distinct().mapNotNull { byKey[it] }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pinBoxV = box
        if (list.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Долгое нажатие на приложение в списке → «На рабочий стол».\nДолгое нажатие на пустое место → виджеты, сеты, настройки."
                setTextColor(Color.WHITE); textSize = 12f; typeface = look.font
                setShadowLayer(6f, 0f, 2f, 0xAA000000.toInt())
                setPadding(look.dp(8), look.dp(24), look.dp(8), 0)
            })
            return box
        }
        for (row in list.chunked(cols)) {
            val rl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (a in row) rl.addView(cell(a, true, true), LinearLayout.LayoutParams(0, -2, 1f))
            repeat(cols - row.size) { rl.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            box.addView(rl)
        }
        return box
    }

    private fun dockView(): View {
        val s = look.pal.surface
        val d = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.argb(0xCC, Color.red(s), Color.green(s), Color.blue(s)))
                cornerRadius = look.dp(30f).toFloat()
            }
            setPadding(look.dp(8), look.dp(4), look.dp(8), look.dp(4))
        }
        for (a in tokens("dockApps", defaultDock()).mapNotNull { byKey[it] }.take(4))
            d.addView(cell(a, false, false), LinearLayout.LayoutParams(0, -2, 1f))
        val holder = FrameLayout(this)
        val btn = TextView(this).apply {
            text = "⌃"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(look.pal.bg); typeface = look.font
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(look.pal.accent) }
            setOnClickListener { openDrawer() }
        }
        holder.addView(btn, FrameLayout.LayoutParams(look.dp(44), look.dp(44), Gravity.CENTER))
        d.addView(holder, LinearLayout.LayoutParams(0, look.dp(60), 1f))
        return d
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int): Any = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val c = (cv as? Cell) ?: Cell(this@HomeActivity, look, false, true)
            c.bind(shown[p])
            return c
        }
    }

    // ---------- плавные анимации ----------

    private fun introAnim() {
        val items = ArrayList<View>()
        for (i in 0 until widgetBox.childCount) items.add(widgetBox.getChildAt(i))
        pinBoxV?.let { for (i in 0 until it.childCount) items.add(it.getChildAt(i)) }
        dockV?.let { items.add(it) }
        items.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = look.dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(look.dur(45L * i)).setDuration(look.dur(460))
                .setInterpolator(look.emphasized).start()
        }
    }

    private fun popIn(v: View) {
        v.alpha = 0f; v.scaleX = 0.88f; v.scaleY = 0.88f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(look.dur(520)).setInterpolator(look.spring()).start()
    }

    /** p: 0 = закрыт, 1 = открыт. Домашний экран уходит назад, фон размывается. */
    private fun setDrawerProgress(raw: Float) {
        val p = raw.coerceIn(0f, 1f)
        drawerP = p
        val h = if (rootV.height > 0) rootV.height.toFloat() else 2000f
        drawer.visibility = if (p <= 0.002f) View.GONE else View.VISIBLE
        when (sp.getInt("drawerAnim", 0)) {
            0 -> { drawer.translationY = (1f - p) * h; drawer.alpha = min(1f, p * 4f); drawer.scaleX = 1f; drawer.scaleY = 1f }
            1 -> { drawer.translationY = 0f; drawer.alpha = p; val s = 0.92f + 0.08f * p; drawer.scaleX = s; drawer.scaleY = s }
            else -> { drawer.translationY = 0f; drawer.alpha = p; drawer.scaleX = 1f; drawer.scaleY = 1f }
        }
        val s = 1f - 0.06f * p
        homeScroll.alpha = 1f - p; homeScroll.scaleX = s; homeScroll.scaleY = s
        dockV?.let { it.alpha = 1f - p; it.translationY = p * look.dp(48) }
        if (Build.VERSION.SDK_INT >= 31 && sp.getBoolean("blur", true)) {
            try { window.setBackgroundBlurRadius((p * look.dp(34)).toInt()) } catch (e: Exception) {}
        }
    }

    private fun animateDrawer(to: Float) {
        val old = drawerAnim; drawerAnim = null; old?.cancel()
        val from = drawerP
        val ms = ((if (to > from) 380L else 300L) * max(0.4f, abs(to - from))).toLong()
        val d = look.dur(ms)
        if (d == 0L) { setDrawerProgress(to); return }
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = d
        a.interpolator = look.emphasized
        a.addUpdateListener { setDrawerProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (drawerAnim === an) { drawerAnim = null; setDrawerProgress(to) }
            }
        })
        drawerAnim = a
        a.start()
    }

    private fun prepareDrawer() {
        search.setText("")
        ordered = sortedApps()
        shown = ordered
        adapter.notifyDataSetChanged()
        grid.setSelection(0)
    }

    private fun openDrawer() {
        if (drawerOpen) return
        prepareDrawer()
        drawerOpen = true
        tick(null)
        animateDrawer(1f)
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        animateDrawer(0f)
    }

    // ---------- пасхалки ----------

    private fun jellyEgg() {
        tick(grid, HapticFeedbackConstants.LONG_PRESS)
        Toast.makeText(this, "🍮 Желе-режим!", Toast.LENGTH_SHORT).show()
        grid.post {
            for (i in 0 until grid.childCount) {
                val c = grid.getChildAt(i)
                c.pivotX = c.width / 2f; c.pivotY = c.height / 2f
                val delay = (i % 8) * 40L
                ObjectAnimator.ofFloat(c, View.ROTATION, 0f, -14f, 12f, -8f, 5f, 0f).apply {
                    duration = 700; startDelay = delay; start()
                }
                ObjectAnimator.ofPropertyValuesHolder(
                    c,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.25f, 0.9f, 1.1f, 1f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.8f, 1.15f, 0.95f, 1f)
                ).apply { duration = 700; startDelay = delay; start() }
            }
        }
    }

    private fun aboutEgg() {
        AlertDialog.Builder(this)
            .setTitle("FxWall 🍮")
            .setMessage("Сделано с любовью и щепоткой желе.\n\nПасхалок тут больше одной. Тапни по названию в настройках… несколько раз.")
            .setPositiveButton("Ок", null).show()
    }

    // ---------- действия ----------

    private fun launch(a: AppEntry, v: View?) {
        sp.edit().putInt("u:" + a.key, sp.getInt("u:" + a.key, 0) + 1).apply()
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            when (sp.getInt("launchAnim", 0)) {
                0 -> if (v != null) startActivity(i, ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle())
                else startActivity(i)
                1 -> startActivity(i, ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
                else -> { startActivity(i); overridePendingTransition(0, 0) }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun menu(a: AppEntry, v: View) {
        tick(v, HapticFeedbackConstants.LONG_PRESS)
        val pm = PopupMenu(this, v)
        val pinned = tokens("pins", emptyList()).contains(a.key)
        val docked = tokens("dockApps", defaultDock()).contains(a.key)
        pm.menu.add(0, 1, 0, if (pinned) "Убрать с рабочего стола" else "На рабочий стол")
        pm.menu.add(0, 2, 0, if (docked) "Убрать из дока" else "В док")
        pm.menu.add(0, 3, 0, "О приложении")
        pm.menu.add(0, 4, 0, "Удалить")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> toggle("pins", a.key, emptyList(), 100)
                2 -> toggle("dockApps", a.key, defaultDock(), 4)
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.cn.packageName)))
                4 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.cn.packageName)))
                else -> {}
            }
            true
        }
        pm.show()
    }

    private fun toggle(key: String, item: String, def: List<String>, max: Int) {
        val list = tokens(key, def).toMutableList()
        if (list.contains(item)) list.remove(item)
        else if (list.size < max) list.add(item)
        else { Toast.makeText(this, "Нет места", Toast.LENGTH_SHORT).show(); return }
        saveTokens(key, list)
        setContentView(buildUi())
    }

    private fun openSettings(tab: Int) = startActivity(Intent(this, MainActivity::class.java).putExtra("tab", tab))

    private fun homeMenu() {
        val items = arrayOf("Добавить виджет", "Сеты и стили", "Обои", "Настройки лаунчера")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) {
                0 -> widgetPicker()
                1 -> openSettings(1)
                2 -> openSettings(0)
                3 -> openSettings(2)
                else -> {}
            }
        }.show()
    }

    // ---------- виджеты ----------

    private fun fillWidgets() {
        widgetBox.removeAllViews()
        val list = (sp.getString("wlist", "b:clock") ?: "").split(",").filter { it.isNotBlank() }
        for (tk in list) {
            val v: View? = when {
                tk == "b:clock" -> ClockWidget(this, look)
                tk == "b:battery" -> BatteryWidget(this, look)
                tk.startsWith("a:") -> makeHost(tk.substring(2).toIntOrNull() ?: -1)
                else -> null
            }
            if (v == null) continue
            v.setOnLongClickListener { confirmRemove(tk); true }
            widgetBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = look.dp(12) })
        }
    }

    private fun popLastWidget() {
        if (widgetBox.childCount > 0) {
            tick(null)
            popIn(widgetBox.getChildAt(widgetBox.childCount - 1))
        }
    }

    private fun makeHost(id: Int): View? {
        if (id < 0) return null
        return try {
            val info = awm.getAppWidgetInfo(id) ?: return null
            val hv = host.createView(this, id, info)
            hv.setAppWidget(id, info)
            hv.minimumHeight = maxOf(info.minHeight, look.dp(80))
            val rad = look.dp(look.radiusDp).toFloat()
            hv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, rad) }
            }
            hv.clipToOutline = true
            val dn = resources.displayMetrics.density
            hv.post {
                val wd = (hv.width / dn).toInt(); val hd = (hv.height / dn).toInt()
                try { hv.updateAppWidgetSize(Bundle(), wd, hd, wd, hd) } catch (e: Exception) {}
            }
            hv
        } catch (e: Exception) { null }
    }

    private fun widgetPicker() {
        val provs: List<AppWidgetProviderInfo> = awm.installedProviders
        val pm = packageManager
        val labels = ArrayList<String>()
        labels.add("Часы (стиль сета)")
        labels.add("Батарея (стиль сета)")
        for (p in provs) {
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() } catch (e: Exception) { p.provider.packageName }
            labels.add((p.loadLabel(pm) ?: "Виджет") + " — " + app)
        }
        AlertDialog.Builder(this).setTitle("Виджеты").setItems(labels.toTypedArray()) { _, w ->
            when (w) {
                0 -> { saveTokens("wlist", (sp.getString("wlist", "b:clock") ?: "").split(",").filter { it.isNotBlank() } + "b:clock"); fillWidgets(); popLastWidget() }
                1 -> { saveTokens("wlist", (sp.getString("wlist", "b:clock") ?: "").split(",").filter { it.isNotBlank() } + "b:battery"); fillWidgets(); popLastWidget() }
                else -> addProvider(provs[w - 2])
            }
        }.show()
    }

    private fun addProvider(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        val ok = try { awm.bindAppWidgetIdIfAllowed(id, info.provider) } catch (e: Exception) { false }
        if (ok) configureOrAdd(id, info)
        else {
            pendingId = id
            try {
                startActivityForResult(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), reqBind
                )
            } catch (e: Exception) {
                host.deleteAppWidgetId(id)
                Toast.makeText(this, "Система не разрешила добавить этот виджет", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun configureOrAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            pendingId = id
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, reqConf, null) }
            catch (e: Exception) { finishAdd(id) }
        } else finishAdd(id)
    }

    private fun finishAdd(id: Int) {
        val list = (sp.getString("wlist", "b:clock") ?: "").split(",").filter { it.isNotBlank() }
        saveTokens("wlist", list + "a:$id")
        fillWidgets()
        popLastWidget()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == reqBind) {
            val info = if (res == RESULT_OK) awm.getAppWidgetInfo(pendingId) else null
            if (info != null) configureOrAdd(pendingId, info) else host.deleteAppWidgetId(pendingId)
        } else if (req == reqConf) {
            if (res == RESULT_OK) finishAdd(pendingId) else host.deleteAppWidgetId(pendingId)
        }
    }

    private fun confirmRemove(token: String) {
        AlertDialog.Builder(this).setTitle("Удалить виджет?")
            .setPositiveButton("Удалить") { _, _ ->
                if (token.startsWith("a:")) token.substring(2).toIntOrNull()?.let { host.deleteAppWidgetId(it) }
                val list = (sp.getString("wlist", "b:clock") ?: "").split(",").filter { it.isNotBlank() && it != token }
                saveTokens("wlist", list)
                fillWidgets()
            }
            .setNegativeButton("Отмена", null).show()
    }
}
