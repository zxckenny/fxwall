package com.fxwall

import android.content.Context
import android.graphics.Color
import org.json.JSONObject
import java.io.File

/** Сет = шрифт + форма/стиль иконок + стиль виджетов + цвета + пресет обоев. */
class FxSet(
    val id: String, val name: String, val dark: Boolean,
    val bg: Int, val surface: Int, val text: Int, val accent: Int,
    val font: String, val shape: String, val style: String, val widget: String,
    val radius: Int, val dynamic: Boolean,
    val effect: Int, val hue: Int, val mono: Boolean, val colorMode: Int
) {
    private fun hex(c: Int) = String.format("#%08X", c)

    fun toJson(): String = JSONObject().apply {
        put("name", name); put("dark", dark)
        put("bg", hex(bg)); put("surface", hex(surface)); put("text", hex(text)); put("accent", hex(accent))
        put("font", font)               // sans-serif, sans-serif-light, monospace, serif, ... или custom
        put("iconShape", shape)         // circle, squircle, rounded, square, none
        put("iconStyle", style)         // original, mono, accent
        put("widget", widget)           // dot, ios, md3, neon, aero, min
        put("radius", radius); put("dynamic", dynamic)
        put("effect", effect)           // 0..6
        put("hue", hue); put("mono", mono); put("colorMode", colorMode)
    }.toString(2)
}

object Sets {
    private fun c(v: Long) = v.toInt()

    val BUILTIN = listOf(
        FxSet("nothing", "Nothing", true, c(0xFF000000), c(0xFF111111), c(0xFFFFFFFF), c(0xFFD71921),
            "monospace", "circle", "mono", "dot", 28, false, 6, 0, true, 0),
        FxSet("ios", "iOS", false, c(0xFFF2F2F7), c(0xFFFFFFFF), c(0xFF111111), c(0xFF0A84FF),
            "sans-serif", "squircle", "original", "ios", 24, false, 3, 215, false, 0),
        FxSet("material", "Material You", true, c(0xFF1C1B1F), c(0xFF2B2930), c(0xFFE6E1E5), c(0xFFD0BCFF),
            "sans-serif-medium", "squircle", "accent", "md3", 28, true, 5, 265, false, 0),
        FxSet("neon", "Cyberpunk", true, c(0xFF0B0221), c(0xFF1A0B3B), c(0xFF00F0FF), c(0xFFFF2BD6),
            "monospace", "square", "original", "neon", 6, false, 4, 300, false, 0),
        FxSet("aero", "Aero", false, c(0xFFD8F1FF), c(0xFFFFFFFF), c(0xFF0B3C5D), c(0xFF29B6F6),
            "sans-serif-medium", "circle", "original", "aero", 30, false, 5, 195, false, 0),
        FxSet("minimal", "Minimal", true, c(0xFF101010), c(0xFF1E1E1E), c(0xFFE0E0E0), c(0xFFBDBDBD),
            "sans-serif-light", "rounded", "mono", "min", 12, false, 2, 0, true, 0)
    )

    fun fromJson(id: String, s: String): FxSet? = try {
        val o = JSONObject(s)
        fun col(k: String, d: Int) = try { Color.parseColor(o.optString(k, "")) } catch (e: Exception) { d }
        FxSet(
            id, o.optString("name", id), o.optBoolean("dark", true),
            col("bg", c(0xFF101010)), col("surface", c(0xFF1E1E1E)), col("text", Color.WHITE), col("accent", c(0xFF4FC3F7)),
            o.optString("font", "sans-serif"), o.optString("iconShape", "squircle"),
            o.optString("iconStyle", "original"), o.optString("widget", "md3"),
            o.optInt("radius", 24), o.optBoolean("dynamic", false),
            o.optInt("effect", 3), o.optInt("hue", 210), o.optBoolean("mono", false), o.optInt("colorMode", 0)
        )
    } catch (e: Exception) { null }

    private fun dir(ctx: Context) = File(ctx.filesDir, "sets").apply { mkdirs() }

    fun all(ctx: Context): List<FxSet> {
        val user = dir(ctx).listFiles()?.filter { it.extension == "json" }?.sortedBy { it.name }
            ?.mapNotNull { fromJson("u_" + it.nameWithoutExtension, it.readText()) } ?: emptyList()
        return BUILTIN + user
    }

    fun current(ctx: Context): FxSet {
        val id = Prefs.sp(ctx).getString("setId", "nothing")
        return all(ctx).firstOrNull { it.id == id } ?: BUILTIN[0]
    }

    fun apply(ctx: Context, s: FxSet) {
        Prefs.sp(ctx).edit()
            .putString("setId", s.id)
            .putInt("effect", s.effect).putInt("hue", s.hue)
            .putBoolean("mono", s.mono).putInt("colorMode", s.colorMode)
            .putInt("ovShape", 0).putInt("ovStyle", 0).putInt("ovWidget", 0)
            .putInt("ovFont", 0).putInt("ovRadius", 0)
            .apply()
    }

    fun importJson(ctx: Context, text: String): FxSet? {
        val tmp = fromJson("tmp", text) ?: return null
        val slug = tmp.name.lowercase().replace(Regex("[^a-z0-9а-я]+"), "_").trim('_').ifEmpty { "set" }
        val id = slug + "_" + (text.hashCode() and 0xffff)
        File(dir(ctx), "$id.json").writeText(text)
        return fromJson("u_$id", text)
    }
}
